from bpmsim.resources import resource

class schedule():
    def __init__(self, res, timetable=[]):
        if type(res) != resource:
            print("Please enter a resource of class 'resource'.")
        elif type(timetable) != list:
            print("Please enter a list in timetable.")
        else:
            for time in timetable:
                if type(time) not in (int, float, complex):
                    print("Please enter numbers in timetable.")
                else:         
                    self.resource = res
                    self.timetable = timetable
                    self.interval = sum(timetable)
                    self.wait = 0
    
    def getResource(self):
        return(self.resource)
    def getTimetable(self):
        return(self.timetable)
    def getInterval(self):
        return(self.interval)
    def getWait(self):
        return(self.wait)
    
    def setResource(self, res):
        self.resource = res
    def setWait(self, wait, add=False):
        if add:
            self.wait += wait
        else:
            self.wait = wait
    
    def runSchedule(self, env, wait):
        yield env.timeout(wait)
        timeschedule = self.timetable
        while len(timeschedule) > 0:
            yield env.timeout(timeschedule[0])
            timeschedule.pop(0)
            if len(timeschedule) > 0:
                useList = []
                for i in range(self.getResource().capacity):
                    useList.append(self.getResource().request(priority=-1000, preempt=True))
                for use in useList:
                    yield use
                yield env.timeout(timeschedule[0])
                for i in range(self.getResource().capacity):
                    self.getResource().release(useList[i])
                timeschedule.pop(0)